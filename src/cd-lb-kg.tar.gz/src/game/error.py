# -*- Mode: python; indent-tabs-mode: t; -*-
# vim: set noexpandtab:
"""
error module
"""

class Error(Exception):
	"A game error, which triggers the effects given in the spec."
	pass
